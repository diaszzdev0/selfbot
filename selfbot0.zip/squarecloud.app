DISPLAY_NAME=Selfbot Manager
DESCRIPTION=Selfbot Discord com painel Flask
MAIN=app.py
MEMORY=512
VERSION=recommended
START=python app.py
PORT=80
ID=67188c49ce2042fabe286376f92bf9f2
