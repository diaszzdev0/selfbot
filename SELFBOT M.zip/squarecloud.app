ID=e810b26c255944519ba9236f34f334ca
DISPLAY_NAME=Selfbot Manager
DESCRIPTION=Selfbot Discord com painel Flask
MAIN=app.py
VERSION=recommended
MEMORY=512
START=python app.py
